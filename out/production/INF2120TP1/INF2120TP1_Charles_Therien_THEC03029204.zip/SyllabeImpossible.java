public class SyllabeImpossible extends Exception {

    public SyllabeImpossible(){
        super();
    }

    public SyllabeImpossible(String mess){
        super(mess);
    }
}
